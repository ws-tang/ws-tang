function enableBookButton(chkboxAgree) {
    if (chkboxAgree === null || chkboxAgree === undefined) {
        return;
    }

    let btn = document.getElementById('btnBookNow');
    if (btn === null || btn === undefined) {
        return;
    }

    btn.disabled = !chkboxAgree.checked;
}